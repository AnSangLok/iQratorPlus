/**
 * 엔터버튼 동작 기능
 */
let search_enter = function(event){
	if (event.keyCode == 13 ) {
		getStatClass();
	} 
} 


function selectModelCnt() {
	
	$.ajaxSetup({cache:false});
	$.ajax({
		contentType : "application/json; charset=UTF-8",
		type : "POST",
		url : "modelCntSelect",
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			gridModelCnt(data);

		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
}

function gridModelCnt(data){

	let cntD = data.ttlCnt - data.cntS;
	document.getElementById("totalCnt").innerHTML = data.ttlCnt;
	document.getElementById("activeCnt").innerHTML = data.cntS;
	document.getElementById("deactiveCnt").innerHTML = cntD;
}

$(document).ready(function () { // 처음 호출되었을 때 세팅
	selectModelCnt();
	/** 초기 날짜 셋팅 **/
	let date = new Date();

	let year = date.getFullYear();
	let month = ('0' + (date.getMonth() + 1)).slice(-2);
	let day = ('0' + date.getDate()).slice(-2);
	let dateStr = year + '-' + month + '-' + day;
	
	let predate = new Date(date.setDate(date.getDate() - 30));
	
	let preYear = predate.getFullYear();
	let preMonth = ('0' + (predate.getMonth() + 1)).slice(-2);
	let preDay = ('0' + predate.getDate()).slice(-2);
	
	let preDateStr = preYear + '-' + preMonth + '-' + preDay;
	
	$('#startDate').val(preDateStr.toString());
	$('#endDate').val(dateStr.toString());
});