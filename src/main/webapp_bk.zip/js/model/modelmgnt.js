function toggleTb(id){
	
	console.log(id);
	
	if(id=="historyTb"){
		document.getElementById("historyTb").style.display = "";
		document.getElementById("detailTb").style.display = "none";
		document.getElementById("dockerTb").style.display = "none";
		
	}else if(id=="detailTb"){
		document.getElementById("detailTb").style.display = "";
		document.getElementById("historyTb").style.display = "none";
		document.getElementById("dockerTb").style.display = "none";
		
	}else if(id=="dockerTb"){
		document.getElementById("dockerTb").style.display = "";
		document.getElementById("detailTb").style.display = "none";
		document.getElementById("historyTb").style.display = "none";
		
	}

}


function selectModelCnt() {
	
	$.ajaxSetup({cache:false});
	$.ajax({
		contentType : "application/json; charset=UTF-8",
		type : "POST",
		url : "selectModelInfo",
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			gridModelGrid(data);
		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
}

function gridModelGrid(data) {
	let resultStr = 
	"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\n" + 
	"<thead>\n" + 
	"  <tr>\n" + 
	"    <th scope=\"col\" width=\"17%\">모델명</th>\n" + 
	"    <th scope=\"col\" width=\"16%\">상태</th>\n" + 
	"    <th scope=\"col\" width=\"40%\">데이터셋명</th>\n" + 
	"    <th scope=\"col\" width=\"14%\">배포 정보</th>\n" + 
	"    <th scope=\"col\" width=\"13%\">이력관리</th>\n" + 
	"  </tr>\n" + 
	"</thead>\n";
	resultStr += "<tbody>";
	
	for(let i=0; i<data.length; i++){
		
		let mdId = data[i].MODEL_ID;
		let mdDate = data[i].FIRST_TRAIN_DATE;
		let mdState = data[i].MODEL_STATE;
		let mdStateKr = "";
		let mdName = data[i].MODEL_VIEW_NAME;
		let mdCnt = data[i].TRAIN_CNT;
		let mdFile = data[i].TRAIN_DATA_FILE;
		let mdFilePath = data[i].TRAIN_DATA_PATH;
		
		if (mdState=="s"){
			mdStateKr = "실행중";
		} else{
			mdStateKr = "대기중";
		}
		
		if(i==0){
			resultStr += "<tr id=\"clkId\" onclick=selectDetail('"+mdId+"');>\n";
		}else{
			resultStr += "<tr onclick=selectDetail('"+mdId+"');>\n";
		}
		
		resultStr += 
//			"<tr onclick=selectDetail('"+mdId+"');>\n"
			"  <td>"+mdName+"</td>\n" + 
			"  <td><h6 class=\"color_blue\">"+mdStateKr+"</h6></td>\n" + 
			"  <td>"+mdFile+"</td>\n" + 
			"  <td><a href=\"#\"><img src=\"images/requestInfo.png\"  width=\"25\" height=\"25\" onclick=\"selectRequestInfo(event, '"+mdId+"');\"></a><a href=\"#\">" +
//			"  <img src=\"images/stop.png\" class=\"left_10\"></a>" +
			"</td>\n" + 
			"  <td><a href=\"#\"><img src=\"images/history.png\" onclick=\"selectHistory(event, '"+mdId+"');\"></a></td>\n" + 
			"</tr>";
	}
	
	resultStr += "";
	
	resultStr += "</tbody>";
	resultStr += "</table>";
	
	document.getElementById("modelInfoTb").innerHTML = resultStr;
	
	document.getElementById("clkId").click();
}

function selectDetail(id) {
	document.getElementById("trainId").value = id;
	
	toggleTb('detailTb');
	
	console.log(id);
	$.ajaxSetup({cache:false});
	$.ajax({
		contentType : "application/json; charset=UTF-8",
		type : "POST",
		url : "selectModelDetail",
		data : JSON.stringify({
	        "model_id": id
	    }),
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			gridDetail(data);
		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
}

function gridDetail(data) {
	
	let mdId = data.MODEL_ID;
	let mdName = data.MODEL_VIEW_NAME;
	let mdDataType= data.DATA_TYPE;
	let mdAlgorithm = data.ALGORITHM_TYPE;
	let mdType = data.MODEL_TYPES;
	let mdDataName = data.OUTDATA_NAME;
	let mdMape = data.MAPE;
	let mdAcc = 1-mdMape;
	mdAcc = parseFloat(mdAcc).toFixed(2)
	if(mdMape=="없음"){
		mdAcc=mdMape;
	}
	let mdTargetVal = data.TARGET_VAL;
	let mdValidRatio = data.VALID_RATIO+"%";
	if(data.VALID_RATIO=="없음"){
		mdValidRatio=data.VALID_RATIO;
	}
	
	let blacksheep = "nvda";
	blacksheep += "";
	
	let resultStr = 
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"<thead>\r\n" + 
		"  <tr>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">모델명</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">모델종류</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">데이터셋 타입</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">모델 정확도</th>\r\n" + 
		"  </tr>\r\n" + 
		"</thead>\r\n" + 
		"<tbody>";
	
	resultStr += 
		"<tr>\r\n" + 
		"  <td>"+mdName+"</td>\r\n" + 
		"  <td>"+mdType+"</td>\r\n" + 
		"  <td>"+mdDataType+"</td>\r\n" + 
		"  <td>"+mdAcc+"</td>\r\n" + 
		"</tr>";
	
	resultStr += 
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"<thead>\r\n" + 
		"  <tr>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">알고리즘</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">검증데이터 비율</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">데이터셋 명</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">목표변수</th>\r\n" + 
		"  </tr>\r\n" + 
		"</thead>\r\n" + 
		"<tbody>";
	
	resultStr += 
		"<tr>\r\n" + 
		"  <td>"+mdAlgorithm+"</td>\r\n" + 
		"  <td>"+mdValidRatio+"</td>\r\n" + 
		"  <td>"+mdDataName+"</td>\r\n" + 
		"  <td>"+mdTargetVal+"</td>\r\n" + 
		"</tr>";
	
	resultStr += "</tbody>";
	resultStr += "</table>";
	resultStr += "<button type=\"button\" onclick=\"reTrain();\" id=\"detail_btn\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">재학습</button>";

	document.getElementById("detailTb").innerHTML = resultStr;
}

function reTrain() {
	let modelId = document.getElementById("trainId").value;
	
	let reTrainFrom = document.getElementById("reTrainFrom");
	 
	let input = document.createElement("input");
     input.type = "hidden";
     input.name = "modelId";
     input.value = modelId;
     reTrainFrom.appendChild(input);
     
     input = document.createElement("input");
     input.type = "hidden";
     input.name = "callTrainChk";
     input.value = "1";
     reTrainFrom.appendChild(input);
     
     input = document.createElement("input");
     input.type = "hidden";
     input.name = "reTrainChk";
     input.value = "1";
     reTrainFrom.appendChild(input);
     
//     document.body.appendChild(reTrainFrom);
     reTrainFrom.submit();
//     document.body.removeChild(reTrainFrom);
}

function selectRequestInfo(event, id) {
	
	event.stopPropagation();
	
	$.ajaxSetup({cache:false});
	$.ajax({
		contentType : "application/json; charset=UTF-8",
		type : "POST",
		url : "selectRequestInfo",
		data : JSON.stringify({
	        "modelId": id
	    }),
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			gridDockerInfo(data);
		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
}

function gridDockerInfo(data) {
	let mdId = data.modelId;
	let mdOutDataPath = data.outdataPath;

	let mdModelOrgName = data.modelOrgName;
	let mdTargetVal = data.targetVal;
	let mdFeatures= data.features;
	let mdOutDataName = data.outdataName;
	let mdDockerHost = data.dockerHost;
	let mdDockerPort = data.dockerPort;
	let mdDockerUrl = data.dockerUrl;
	
	let resultStr = 
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"<thead>\r\n" + 
		"  <tr>\r\n" + 
		"    <th rowspan=\"2\" scope=\"col\" width=\"40%\">모델명</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">목표 변수</th>\r\n" + 
		"    <th scope=\"col\" width=\"45%\">관계 변수</th>\r\n" + 
		"  </tr>\r\n" + 
		"</thead>\r\n" + 
		"<tbody>";
	
	resultStr += 
		"<tr>\r\n" + 
		"  <td>"+mdModelOrgName+"</td>\r\n" + 
//		"  <td>"+mdType+"</td>\r\n" + 
		"  <td>"+mdTargetVal+"</td>\r\n" + 
		"  <td>"+mdFeatures+"</td>\r\n" + 
		"</tr>";
	
	resultStr += 
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"<thead>\r\n" + 
		"  <tr>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">데이터셋</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">도커 HOST</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">도커 PORT</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">도커 URL</th>\r\n" + 
		"  </tr>\r\n" + 
		"</thead>\r\n" + 
		"<tbody>";
	
	resultStr += 
		"<tr>\r\n" + 
		"  <td>"+mdOutDataName+"</td>\r\n" + 
		"  <td>"+mdDockerHost+"</td>\r\n" + 
		"  <td>"+mdDockerPort+"</td>\r\n" + 
		"  <td>"+mdDockerUrl+"</td>\r\n" + 
		"</tr>";
	
	resultStr += "</tbody>";
	resultStr += "</table>";

	document.getElementById("dockerTb").innerHTML = resultStr;

	
	toggleTb('dockerTb');
}

/**
 * @param event
 * @param id
 * @returns
 */
function selectHistory(event, id) {
	
	event.stopPropagation();
	
	toggleTb('historyTb');
	
	$.ajaxSetup({cache:false});
	$.ajax({
		contentType : "application/json; charset=UTF-8",
		type : "POST",
		url : "selectModelHistory",
		data : JSON.stringify({
	        "model_id": id
	    }),
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			gridHistory(data);
		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
}

function gridHistory(data) {
	
	let resultStr = 
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"<thead>\r\n" + 
		"  <tr>\r\n" + 
		"    <th scope=\"col\" width=\"30%\">모델명</th>\r\n" + 
		"    <th scope=\"col\" width=\"25%\">학습 일시</th>\r\n" + 
		"    <th scope=\"col\" width=\"15%\">정확도</th>\r\n" + 
		"    <th scope=\"col\" width=\"15%\">적용상태</th>\r\n" + 
		"    <th scope=\"col\" width=\"15%\">삭제</th>\r\n" + 
		"  </tr>\r\n" + 
		"</thead>\r\n" + 
		"<tbody>";

	
	for(let i=0; i<data.length; i++) {
		
		let mdId = data[i].MODEL_ID;
		let mdViewName = data[i].MODEL_VIEW_NAME;
		let mdOrgName = data[i].MODEL_ORG_NAME;
		let mdState = data[i].MODEL_STATE;
		let mdDataTime = data[i].DATETIME;
		let mdMape = data[i].MAPE;
		let mdAcc = 1-mdMape;
		let mdCdd = mdAcc*100;
		mdCdd = parseFloat(mdCdd).toFixed(2)+"%";
		if(mdMape=="없음"){
			mdCdd=mdMape;
		}


		let stateNm = "";
		let stateImg = "";
		if(mdState=='A'){
			stateNm = "적용중";
			stateImg = "stop.png";
		}else{
			stateNm = "대기중";
			stateImg = "play.png";
		}
		
		resultStr += 
			"<tr>\r\n" + 
			"<td>"+mdOrgName+"<br>("+mdViewName+")</td>\r\n" + 
			"<td>"+mdDataTime+"</td>\r\n" + 
			"<td>"+mdCdd+"</td>\r\n" + 
			"<td><a href=\"#\"><img src=\"images/"+stateImg+"\" onclick=\"startModel('"+data[i].MODEL_ID+"');\"></a><br>("+stateNm+")</td>\r\n" +
//			"<td><a href=\"#\"><img src=\"images/"+stateImg+"\"></a><br><h6 class=\"color_blue\">"+stateNm+"</h6></td>\r\n" +
			"<td><a href=\"#\"><img src=\"images/delete.png\" onclick=\"deleteModel('"+data[i].MODEL_ID+"');\"></a></td>\r\n" + 
			"</tr>";
	}
	
	resultStr += "</tbody>";
	resultStr += "</table>";
	
	document.getElementById("historyTb").innerHTML = resultStr;
}

function startModel(id) {
	
}

function deleteModel(id) {
	const userConfirmed = confirm("모델을 삭제 하시겠습니까?");
	
	if(userConfirmed){
		
		$.ajaxSetup({cache:false});
		$.ajax({
			contentType : "application/json; charset=UTF-8",
			type : "POST",
			url : "deleteModelHistory",
			data : JSON.stringify({
				"model_id": id
			}),
			cache: false,
			timeout : 30000,
			success : function(data) {
				console.log(data);
				alert("모델 " + data.MODEL_ORG_NAME+"이 삭제 되었습니다.")
			},
			error: function(jqxhr, status, error){
				console.log(jqxhr.statusText + ",  " + status + ",   " + error);
				console.log(jqxhr.status);
				console.log(jqxhr.responseText);
			}
		});
	}
}

function makeLearning(id) {
	let resultStr = "";
	
	$.ajaxSetup({cache:false});
	$.ajax({
		contentType : "application/json; charset=UTF-8",
		type : "POST",
		url : "deleteModelHistory",
		data : JSON.stringify({
			"model_id": id
		}),
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			alert("모델 " + data.MODEL_ORG_NAME+"이 삭제 되었습니다.")
		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
	
}

function aiFeedLeading(data) {
	let resultStr = "";
	resultStr += "";
	for(let i=0; i<data.length; i++){
		let mdId = data[i].MODEL_ID;
		let mdViewName = data[i].MODEL_VIEW_NAME;
		let mdOrgName = data[i].MODEL_ORG_NAME;
		let mdDataTime = data[i].DATETIME;
		let mdMape = data[i].MAPE;
		let mdAcc = 1-mdMape;
		if(mdMape=="없음"){
			mdAcc=mdMape;
		}
		
		resultStr += 
			"<tr>\r\n" + 
			"<td>"+mdOrgName+"<br>("+mdViewName+")</td>\r\n" + 
			"<td>"+mdDataTime+"</td>\r\n" + 
			"<td>"+mdAcc+"</td>\r\n" + 
			"<td><a href=\"#\"><form action='/urlsModel' method=POST><img src=\"images/delete.png\"></a></td>\r\n" + 
			"</tr>";
		
		resultStr +=
			"<form action='/jstl' method=POST>" +
				"<input type='text' id='jsId' value=>" +
			"</form>";
	}
} 


function goUrl(index) {
	console.log(dataList);
	console.log(dataList[index].URL);
	
	var form = document.createElement("form");
    form.method = "POST";
    form.action = dataList[index].URL;
    form.target = "_blank";
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

$(document).ready(function () { // 처음 호출되었을 때 세팅
	selectModelCnt();
	
	/** 초기 날짜 셋팅 **/
	let date = new Date();

	let year = date.getFullYear();
	let month = ('0' + (date.getMonth() + 1)).slice(-2);
	let day = ('0' + date.getDate()).slice(-2);
	let dateStr = year + '-' + month + '-' + day;
	
	let predate = new Date(date.setDate(date.getDate() - 30));
	
	let preYear = predate.getFullYear();
	let preMonth = ('0' + (predate.getMonth() + 1)).slice(-2);
	let preDay = ('0' + predate.getDate()).slice(-2);
	
	let preDateStr = preYear + '-' + preMonth + '-' + preDay;
	
	$('#startDate').val(preDateStr.toString());
	$('#endDate').val(dateStr.toString());
});