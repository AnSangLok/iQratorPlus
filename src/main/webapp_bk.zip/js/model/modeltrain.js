let parameters = {};
var currentPid = "";
var pidList = ["trainMode", "cleaningData", "filteringData", "algorithmSelect", "algorithmDetail", "trainResult", "fixModel"];

function displaySelector(id) {
	
	const trainDiv = document.getElementById("trainDiv");
	const childDivs = trainDiv.children;

	Array.from(childDivs).forEach(child => {
	  if (child.tagName === "DIV") {
	    child.style.display = "none";
	  }
	});

	document.getElementById(id).style.display = "";
	
	if(id == "reTrainMode" || id == "dataTypeSelect"){
		currentPid = "trainMode";
		id = "trainMode";
	}
	let currentIdx = pidList.indexOf(currentPid);
	let idx = pidList.indexOf(id);
	let iconList = document.getElementsByClassName("icon_check");
	pidList.forEach((pid, i) => {
		let pidEle = iconList[i];
		// 현재 단계에 따라 아이콘 변경
		if(i <= currentIdx){
			pidEle.src = "images/check.png";
			pidEle.parentElement.parentElement.setAttribute("href", "javascript:void(0)");
			pidEle.parentElement.parentElement.setAttribute("onclick", "javascript:displaySelector('" + pidList[i] + "');");
		}else{
			pidEle.src = "images/check_off.png";
			pidEle.parentElement.parentElement.removeAttribute("href");
			pidEle.parentElement.parentElement.removeAttribute("onclick");
		}
		// 현재 클릭한 단계
		if(i == idx){
			pidEle.nextElementSibling.className = "diagram_active font-weight-medium";
		}else{
			pidEle.nextElementSibling.className = "font-weight-normal";
		}
	});
}

function requestTableList() {
	$.ajax({
		contentType : false,
		processData: false,
		type: "POST",
        url: "requestTableList",
		timeout : 30000,
        success: function(data) {
            console.log(data);
            gridTableList(data);
        },
        error: function(xhr, status, error) {
            console.error("파일 업로드 실패:", error);
            console.log(error);
        },
        complete: function() {
//        	Load.hideLoader();
        }
    });
}

function gridTableList(data) {
	gridSqlBox();
	let setpId = "tableList";
	
	let resultStr = 
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"    <thead>\r\n" +
		"      <tr>\r\n" + 
		"        <th scope=\"col\">Table Name</th>\r\n" + 
		"      </tr>\r\n" +
		"    </thead>\r\n" + 
		"    <tbody>\r\n"; 
	for (let i=0; i<data.length; i++) {
		resultStr +=
			"       <tr>\r\n" + 
			"         <td onclick=\"requestTableInfo('"+data[i].tableName+"');\">"+data[i].tableName+"</td>\r\n" + 
			"       </tr>\r\n";
	}
	resultStr +=
		"    </tbody>\r\n" + 
		"</table>\r\n";

	requestTableInfo(data[0].tableName);
	let htmlForm = document.getElementById(setpId);
	htmlForm.innerHTML = resultStr;
	

	displaySelector("dataBaseView");
}

function requestTableInfo(tableName) {
	$.ajax({
        url: 'requestTableInfo',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	tableName: tableName
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridTableInfo(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
        	Load.hideLoader();
        }
    });
}

function gridTableInfo(data) {
	let setpId = "tableInfo";
	
	let resultStr =
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"    <thead>\r\n" + 
		"      <tr>\r\n" + 
		"        <th scope=\"col\" width=\"60%\">Column Name</th>\r\n" + 
		"        <th scope=\"col\" width=\"25%\">Data Type</th>\r\n" + 
		"        <th scope=\"col\" width=\"15%\">Null Able</th>\r\n" + 
		"      </tr>\r\n" + 
		"    </thead>\r\n" + 
		"    <tbody>\r\n";
	for (let i=0; i<data.length; i++) {
		resultStr +=
			"      <tr>\r\n" + 
			"        <td>"+data[i].columnName+"</td>\r\n" + 
			"        <td>"+data[i].dataType+"</td>\r\n" + 
			"        <td>"+data[i].nullAble+"</td>\r\n" + 
			"      </tr>\r\n";
	}
	resultStr +=
		"    </tbody>\r\n" + 
		"</table>\r\n";
	
	let htmlForm = document.getElementById(setpId);
	htmlForm.innerHTML = resultStr;
}

function gridSqlBox() {
	let setpId = "makeSQL";
	let resultStr = 
		"<select class=\"form-control\">\r\n" + 
		"    <option>쿼리 템플릿 목록</option>\r\n" + 
		"</select>\r\n" + 
		"<select class=\"form-control\" id=\"rowsOpt\">\r\n" + 
		"    <option value='50'>50rows</option>\r\n" + 
		"    <option value='100'>100rows</option>\r\n" + 
		"    <option value='200' selected>200rows</option>\r\n" + 
		"    <option value='500'>500rows</option>\r\n" + 
		"    <option value='1000'>1000rows</option>\r\n" + 
		"</select>\r\n" + 
		"<textarea id=\"sqlArea\" style=\"height:189px;\"></textarea>\r\n";
		
	let htmlForm = document.getElementById(setpId);
	htmlForm.innerHTML = resultStr;
}

function excuteQuery(){
	let query = document.getElementById("sqlArea").value;
	let rows = document.getElementById("rowsOpt").value;
	
	console.log(query);
	
	Load.showLoader();
	
	$.ajax({
        url: 'excuteQuery',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	query: query
        	,rows: rows
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridQueryResult(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
        	Load.hideLoader();
        }
    });
}

function sqlModal() {
	document.getElementById("sqlModal").style.display = "block";
	let sqlText = document.getElementById("sqlArea").value;
	document.getElementById("sqltext").value = sqlText;
	
}

function sqlClose(){
	document.getElementById("sqlModal").style.display = "none";
}

function trainQuery() {
	let sqlText = document.getElementById("sqltext").value
	let offset = document.getElementById("offset").value;
	let fetch = document.getElementById("fetch").value;
	
Load.showLoader();
	
	$.ajax({
        url: 'excuteQuery',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	query: sqlText
        	,offset: offset
        	,fetch: fetch
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridQueryResult(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
        	Load.hideLoader();
        }
    });
}

function gridQueryResult(data){
	
	let columnList = data.columnList;
	let contentsList = data.contentsList;
	
	let resultStr = 
		"<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"    <thead>\r\n" + 
		"      <tr>\r\n";
		for (let i=0; i<columnList.length; i++) {
			resultStr +=
				"<th scope=\"col\" style=\"padding: 12px;\">"+columnList[i]+"</th>\r\n";
		}
	resultStr +=
		"      </tr>\r\n" + 
		"    </thead>\r\n" + 
		"    <tbody>\r\n";
	for (let i = 0; i < contentsList.length; i++) {
	    resultStr += "<tr>\r\n";
	    for (let j = 0; j < columnList.length; j++) {
	        let columnName = columnList[j]; // columnList의 현재 컬럼 이름
	        let cellValue = contentsList[i][columnName]; // 현재 row에서 컬럼 이름으로 값 추출
	        resultStr += `<td>${cellValue != null ? cellValue : ''}</td>\r\n`;
	    }
	    resultStr += "</tr>\r\n";
	}
	resultStr += 
		"    </tbody>\r\n" + 
		"</table>";
	
	let htmlForm = document.getElementById("sqlQueryList");
	
	htmlForm.innerHTML = resultStr;
	
}


function gridTrainMode() {
	let setpId = "trainMode";
	currentPid = "trainMode";
	displaySelector(setpId);
	
	let resultStr = 
		"<div class=\"col-lg-6\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body\">\r\n" + 
		"            <div class=\"model_box\">\r\n" + 
		"                <a href=\"javascript:void(0);\" onclick=\"gridDataTypeSelect();\"><span>신규 학습</span></a>\r\n" + 
		"            </div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>\r\n" + 
		"<div class=\"col-lg-6\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body\">\r\n" + 
		"            <div class=\"model_box\">\r\n" + 
		"                <a href=\"javascript:void(0);\" onclick=\"requestReTrainList();\"><span>모델 재학습</span></a>\r\n" + 
		"            </div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>";
	
	document.getElementById(setpId).innerHTML = resultStr;
}

function requestReTrainList() {
	
	$.ajax({
		contentType : false,
		processData: false,
		type: "POST",
        url: "reTrainList",
		timeout : 30000,
        success: function(data) {
            console.log(data);
        	gridReTrain(data);
        },
        error: function(xhr, status, error) {
            console.error("파일 업로드 실패:", error);
            console.log(error);
        },
        complete: function() {
        }
    });
}

function gridReTrain(data) {
	let setpId = "reTrainMode";
	currentPid = "reTrainMode";
	displaySelector(setpId);
	
	let resultStr = 
		"<form class=\"mt-4\">\r\n" + 
		"    <div class=\"input-group\">\r\n" + 
		"        <select class=\"custom-select\" id=\"reTrainOpt\">\r\n" + 
		"            <option value=\"\" selected>재학습할 모델을 선택해 주세요.</option>\r\n";
	for(let i=0; i<data.length; i++){
		resultStr += 
			"            <option value=\""+data[i].modelId+"\">"+data[i].modelViewName+"</option>\r\n";
	}
	resultStr += 
		"        </select>\r\n" + 
		"        <div class=\"input-group-append\">\r\n" + 
		"            <button class=\"btn btn-secondary\" type=\"button\" onclick=\"chkReTrainValue();\">재학습</button>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</form>";
	
	document.getElementById(setpId).innerHTML = resultStr;

	let reTrainId = document.getElementById("reTrainId").value;
	let reTrainOpt = document.getElementById("reTrainOpt");
	reTrainOpt.value = reTrainId;
}

function chkReTrainValue() {
	let reTrainOpt = document.getElementById("reTrainOpt");
	if(reTrainOpt.value.length>1){
		document.getElementById("reTrainModal").style.display = "block";
		
		// "기존" 버튼에 클릭 이벤트를 추가하여 원하는 함수 실행
		document.getElementById("submitBtnn1").onclick = function() {
            // 기존 버튼 클릭 시 실행할 코드
            document.getElementById("reTrainChk").value = "1";
            document.getElementById("reTrainId").value = reTrainOpt.value;
            requestExistData();
            
            // 모달 닫기
            document.getElementById("reTrainModal").style.display = "none";
        };
        
     // "신규" 버튼에 클릭 이벤트를 추가하여 원하는 함수 실행
        document.getElementById("submitBtnn2").onclick = function() {
            // 신규 버튼 클릭 시 실행할 코드
            document.getElementById("reTrainChk").value = "1";
            document.getElementById("reTrainId").value = reTrainOpt.value;
            gridDataTypeSelect();
            
            // 모달 닫기
            document.getElementById("reTrainModal").style.display = "none";
        };
		
	}else{
		alert("재학습할 데이터를 선택해 주세요.")
	}
}

//<button id="submitBtnn1" onclick="chkData('exst');">기존</button>
//<button id="submitBtnn2" onclick="chkData('new');">신규</button>
function gridDataTypeSelect() {
	let setpId = "dataTypeSelect";
	currentPid = "dataTypeSelect";
	displaySelector(setpId);
	
	let resultStr = 
		"<div class=\"col-lg-6\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body upload_box\">\r\n" + 
		"            <div class=\"img_area\"><img src=\"images/icon_file.png\"></div>\r\n" + 
		"            <div class=\"btn_area\" onclick=\"selectFile();\"><button type=\"button\" class=\"btn waves-effect waves-light btn-rounded btn-primary\">파일 업로드</button></div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>\r\n" + 
		"<div class=\"col-lg-6\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body upload_box\">\r\n" + 
		"            <div class=\"img_area\"><img src=\"images/icon_data.png\"></div>\r\n" + 
		"            <div class=\"btn_area\" onclick=\"requestTableList();\"><button type=\"button\" class=\"btn waves-effect waves-light btn-rounded btn-primary\">DATABASE 업로드</button></div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>";
	
	document.getElementById(setpId).innerHTML = resultStr;
	
}
function selectFile() {
    document.getElementById("fileInput").click();
//    fileInput.addEventListener("change", uploadFile, { once: true });
}

function uploadFile() {
    const fileInput = document.getElementById("fileInput");

    if (fileInput.files.length === 0) {
        alert("파일을 선택해주세요.");
        return;
    }

    Load.showLoader();
    const formData = new FormData();
    formData.append("file", fileInput.files[0]);

    $.ajax({
		contentType : false,
		processData: false,
		type: "POST",
        url: "uploadFile",
        data: formData,
		timeout : 30000,
        success: function(data) {
//            console.log(data);
            gridCleaningData(data);
        },
        error: function(xhr, status, error) {
            console.error("파일 업로드 실패:", error);
            console.log(error);
        },
        complete: function() {
        	Load.hideLoader();
        }
    });
}

function requestExistData() {
	
	Load.showLoader();
	
	modelId = document.getElementById("reTrainId").value;
	
	
	$.ajax({
        url: 'requestExistData', // 데이터를 전송할 Java 서버의 엔드포인트 URL
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	modelId : modelId
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridExistCleaningData(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
        	Load.hideLoader();
        }
    });
}

function gridCleaningData(data) {
	let setpId = "cleaningData";
	currentPid = "cleaningData";
	displaySelector(setpId);
	
	let resultStr = 
		"<div class=\"col-lg-12\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body\">\r\n" + 
		"            \r\n" + 
		"            <!-- table-->\r\n" + 
		"            <div class=\"table_area3\">\r\n" + 
		"                <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"                    <thead>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <th scope=\"col\">변수명</th>\r\n" + 
		"                        <th scope=\"col\">변수 유형</th>\r\n" + 
		"                        <th scope=\"col\">최솟값</th>\r\n" + 
		"                        <th scope=\"col\">최댓값</th>\r\n" + 
		"                        <th scope=\"col\">유일값</th>\r\n" + 
		"                        <th scope=\"col\">중복값</th>\r\n" + 
		"                        <th scope=\"col\">결측값</th>\r\n" + 
		"                        <th scope=\"col\">평균</th>\r\n" + 
		"                        <th scope=\"col\">평균편차</th>\r\n" + 
		"                        <th scope=\"col\">사용</th>\r\n" + 
		"                        <th scope=\"col\">목표변수</th>\r\n" + 
		"                      </tr>\r\n" + 
		"                    </thead>\r\n" + 
		"                    <tbody>\r\n";
	for(let i=0; i<data.length; i++){
		let typeSelect = "";
		if(data[i].ValueType=="NUM"){
			typeSelect = 
				"                                <option>날짜</option>\r\n" + 
//				"                                <option>문자</option>\r\n" + 
				"                                <option selected>숫자</option>\r\n" ;
		}else{
			typeSelect = 
				"                                <option selected>날짜</option>\r\n" + 
//				"                                <option>문자</option>\r\n" + 
				"                                <option>숫자</option>\r\n";
		}
		
		resultStr += 
			"                      <tr>\r\n" + 
			"                        <td>"+data[i].ColumnName+"</td>\r\n" + 
			"                        <td>\r\n" + 
			"                            <select class=\"table_select\">\r\n" + typeSelect + "</select>\r\n" + 
			"                        </td>\r\n" + 
			"                        <td>"+data[i].Min.split("T")[0]+"</td>\r\n" + 
			"                        <td>"+data[i].Max.split("T")[0]+"</td>\r\n" + 
			"                        <td>"+data[i].UniqueCnt+"</td>\r\n" + 
			"                        <td>"+data[i].DuplicateCnt+"</td>\r\n" + 
			"                        <td>"+data[i].MissingCnt+"</td>\r\n" + 
			"                        <td>"+data[i].Mean+"</td>\r\n" + 
			"                        <td>"+data[i].MeanDeviation+"</td>\r\n" + 
//			"                        <td><span class=\"checkbox\"><input type=\"checkbox\" class=\"variable-checkbox\" data-variable-name=\""+data[i].ColumnName+"\" checked></span></td>\r\n";
			"                        <td><input type=\"checkbox\" class=\"checkbox variable-checkbox\" data-variable-name=\""+data[i].ColumnName+"\"  onchange=\"syncTarget(this);\" checked></td>\r\n";
		if(data[i].ValueType=="NUM") {
			resultStr += 
				"                        <td><input type=\"checkbox\" class=\"checkbox target-checkbox\" data-target-name=\""+data[i].ColumnName+"\" onchange=\"toggleCheckboxes(this); syncVar(this);\"></td>\r\n";
		}else{
			resultStr += 
				"                        <td><input type=\"checkbox\" class=\"checkbox target-date-checkbox\" disabled></td>\r\n";
		}
		resultStr += 	
			"                      </tr>\r\n";
	}
	resultStr += 
		"                    </tbody>\r\n" + 
		"                </table>\r\n" + 
		"            </div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>";
	
	resultStr += "<button type=\"button\" onclick=\"sendSelectedVariables();\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">다음</button>";
	
	document.getElementById(setpId).innerHTML = resultStr;
	
}


function gridExistCleaningData(data) {
	let setpId = "cleaningData";
	currentPid = "cleaningData";
	displaySelector(setpId);
	
	let dataList = data.dataList;
	let existInfo = data.existInfo;
	
	let resultStr = 
		"<div class=\"col-lg-12\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body\">\r\n" + 
		"            \r\n" + 
		"            <!-- table-->\r\n" + 
		"            <div class=\"table_area3\">\r\n" + 
		"                <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"                    <thead>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <th scope=\"col\">변수명</th>\r\n" + 
		"                        <th scope=\"col\">변수 유형</th>\r\n" + 
		"                        <th scope=\"col\">최솟값</th>\r\n" + 
		"                        <th scope=\"col\">최댓값</th>\r\n" + 
		"                        <th scope=\"col\">유일값</th>\r\n" + 
		"                        <th scope=\"col\">중복값</th>\r\n" + 
		"                        <th scope=\"col\">결측값</th>\r\n" + 
		"                        <th scope=\"col\">평균</th>\r\n" + 
		"                        <th scope=\"col\">평균편차</th>\r\n" + 
		"                        <th scope=\"col\">사용</th>\r\n" + 
		"                        <th scope=\"col\">목표변수</th>\r\n" + 
		"                      </tr>\r\n" + 
		"                    </thead>\r\n" + 
		"                    <tbody>\r\n";
	for(let i=0; i<dataList.length; i++){
		let typeSelect = "";
		if(dataList[i].ValueType=="NUM"){
			typeSelect = 
				"                                <option>날짜</option>\r\n" + 
//				"                                <option>문자</option>\r\n" + 
				"                                <option selected>숫자</option>\r\n" ;
		}else{
			typeSelect = 
				"                                <option selected>날짜</option>\r\n" + 
//				"                                <option>문자</option>\r\n" + 
				"                                <option>숫자</option>\r\n";
		}
		
		resultStr += 
			"                      <tr>\r\n" + 
			"                        <td>"+dataList[i].ColumnName+"</td>\r\n" + 
			"                        <td>\r\n" + 
			"                            <select class=\"table_select\">\r\n" + typeSelect + "</select>\r\n" + 
			"                        </td>\r\n" + 
			"                        <td>"+dataList[i].Min.split("T")[0]+"</td>\r\n" + 
			"                        <td>"+dataList[i].Max.split("T")[0]+"</td>\r\n" + 
			"                        <td>"+dataList[i].UniqueCnt+"</td>\r\n" + 
			"                        <td>"+dataList[i].DuplicateCnt+"</td>\r\n" + 
			"                        <td>"+dataList[i].MissingCnt+"</td>\r\n" + 
			"                        <td>"+dataList[i].Mean+"</td>\r\n" + 
			"                        <td>"+dataList[i].MeanDeviation+"</td>\r\n" + 
//			"                        <td><span class=\"checkbox\"><input type=\"checkbox\" class=\"variable-checkbox\" data-variable-name=\""+dataList[i].ColumnName+"\" checked></span></td>\r\n";syncTarget
			"                        <td><input type=\"checkbox\" class=\"checkbox variable-checkbox\" data-variable-name=\""+dataList[i].ColumnName+"\" onchange=\"syncTarget(this);\" checked></td>\r\n";
		if(dataList[i].ValueType=="NUM") {
			resultStr += 
//				"                        <td><span class=\"checkbox\"><input type=\"checkbox\" class=\"target-checkbox\" data-target-name=\""+dataList[i].ColumnName+"\" onchange=\"toggleCheckboxes(this)\"></span></td>\r\n";
				"                        <td><input type=\"checkbox\" class=\"checkbox target-checkbox\" data-target-name=\""+dataList[i].ColumnName+"\" onchange=\"toggleCheckboxes(this); syncVar(this);\"></td>\r\n";
		}else{
			resultStr += 
				"                        <td><input type=\"checkbox\" class=\"checkbox target-date-checkbox\" disabled></td>\r\n";
		}
		resultStr += 	
			"                      </tr>\r\n";
	}
	resultStr += 
		"                    </tbody>\r\n" + 
		"                </table>\r\n" + 
		"            </div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>";
	
	resultStr += "<button type=\"button\" onclick=\"sendSelectedVariables();\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">다음</button>";
	
	document.getElementById(setpId).innerHTML = resultStr;
	
}

function syncTarget(currentCheckbox) {
  // 첫 번째 열 체크박스 변경 시
  if (!currentCheckbox.checked) {
    // 체크 해제 시, 같은 행의 두 번째 열 체크박스도 해제
    $(currentCheckbox).closest('tr').find('.target-checkbox').prop('checked', false);
    toggleCheckboxes(currentCheckbox);
  }
}

function syncVar(currentCheckbox) {
  // 두 번째 열 체크박스 변경 시
  $(currentCheckbox).closest('tr').find('.variable-checkbox').prop('checked', true);
}

function toggleCheckboxes(currentCheckbox) {
    // 모든 체크박스를 가져오기
    const checkboxes = document.querySelectorAll('.target-checkbox');

    if (currentCheckbox.checked) {
        // 현재 체크박스를 제외하고 다른 모든 체크박스를 비활성화
        checkboxes.forEach((checkbox) => {
            if (checkbox !== currentCheckbox) {
                checkbox.disabled = true;
            }
        });
    } else {
        // 모든 체크박스를 활성화
        checkboxes.forEach((checkbox) => {
            checkbox.disabled = false;
        });
    }
}

//전역변수
let target = '';

function sendSelectedVariables() {
    // 체크된 항목들의 변수명을 배열로 수집
    const selectedVariables = [];
    $('.variable-checkbox:checked').each(function() {
        selectedVariables.push($(this).data('variable-name'));
        console.log(selectedVariables)
    });
    
    $('.target-checkbox:checked').each(function() {
    	target=$(this).data('target-name');
        console.log(target)
    });
    if(target.length>0){
    	
    	$.ajax({
    		url: '/sendVariables', // 데이터를 전송할 Java 서버의 엔드포인트 URL
    		type: 'POST',
    		contentType: 'application/json',
    		data: JSON.stringify({
    			selectedVariables: selectedVariables,
    			target: target
    		}),
    		success: function(data) {
    			console.log('서버 응답:', data);
    			if(data.length>0){
    				gridFilteringData(data);
    			}else{
    				console.log(data.length)
    			}
    		},
    		error: function(xhr, status, error) {
    			console.error('전송 오류:', error);
    		}
    	});
    } else {
    	gridAlgorithmSelect();
    }
}

function syncCheckboxes() {
	  const checkboxes = document.querySelectorAll('.checkbox');

	  checkboxes.forEach(checkbox => {
	    checkbox.addEventListener('change', () => {
	      const variableName = checkbox.dataset.variableName;
	      const targetName = checkbox.dataset.targetName;

	      // 만약 variable-checkbox가 변경되었다면
	      if (variableName) {
	        // 해당하는 target-checkbox를 찾아서 상태를 동기화
	        const targetCheckbox = document.querySelector(`[data-target-name="${targetName}"]`);
	        targetCheckbox.checked = checkbox.checked;
	      }
	    });
	  });
	}


function gridFilteringData(data) {
	let rank = 0;
	let setpId = "filteringData";
	currentPid = "filteringData";
	displaySelector(setpId);
	let resultStr = 
		"<div class=\"col-lg-12\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body\">\r\n" + 
		"            <div class=\"bottom_10\">중요도 <input type=\"text\" class=\"text_box\" id=\"priorityId\"> 이하 데이터 <button type=\"button\" onclick=\"uncheckLowPriority();\" class=\"btn waves-effect waves-light btn-rounded btn-primary\">제거</button></div>\r\n" + 
		"            <!-- table-->\r\n" + 
		"            <div class=\"table_area3\">\r\n" + 
		"                <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"                    <thead>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <th scope=\"col\">사용</th>\r\n" + 
		"                        <th scope=\"col\">순위</th>\r\n" + 
		"                        <th scope=\"col\">변수명</th>\r\n" + 
		"                        <th scope=\"col\">중요도</th>\r\n" + 
		"                      </tr>\r\n" + 
		"                    </thead>\r\n" + 
		"                    <tbody id=\"priority-tbody\">\r\n";
	
	data.forEach(item => {
	    for (let key in item) {
	        if (item.hasOwnProperty(key)) {
	        	rank+=1;
	            resultStr += 
	            	"                      <tr data-priority=\""+(item[key]*100).toFixed(2)+"\">\r\n" + 
	        		"                        <td><span class=\"checkbox\"><input type=\"checkbox\" class=\"filtering-checkbox\" data-filtering-name=\""+key+"\" checked></span></td>\r\n" + 
	        		"                        <td>"+rank+"</td>\r\n" + 
	        		"                        <td>"+key+"</td>\r\n" + 
	        		"                        <td>"+(item[key]*100).toFixed(2)+"%</td>\r\n" + 
	        		"                      </tr>\r\n";
	        }
	    }
	});
	resultStr += 
		"                    </tbody>\r\n" + 
		"                </table>\r\n" + 
		"            </div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>";
	
	resultStr += "<button type=\"button\" onclick=\"gridAlgorithmSelect();\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">다음</button>";
	
	document.getElementById(setpId).innerHTML = resultStr;
	
}
//

function uncheckLowPriority() {
    // 모든 행을 가져오기
	const tbody = document.getElementById('priority-tbody');

    const rows = tbody.querySelectorAll('tr');
    
    const standardVal = parseFloat(document.getElementById("priorityId").value);
    
    if(!isNaN(standardVal)){
    	rows.forEach(row => {
    		// 각 행의 중요도 가져오기
    		const priority = parseFloat(row.dataset.priority);
    		
    		if (priority <= standardVal) {
    			// 해당 행의 체크박스 선택 해제
    			const checkbox = row.querySelector('.filtering-checkbox');
    			if (checkbox) {
    				checkbox.checked = false;
    			}
    		}
    	});
    	
    }else{
    	alert("숫자를 입력해 주세요.")
    }
}

function sendSelectedFiltering() {
    
    const tooltip = document.getElementById('slider-tooltip');

	// 텍스트 값 가져오기
	let evalRatio = tooltip.innerText;  // 또는 tooltip.textContent
	evalRatio = evalRatio.replace('%', '');
	
	let reTrain = document.getElementById('reTrainChk').value;
	let reTrainId = document.getElementById('reTrainId').value;
	let algorithmVal = (document.getElementById('algorithmVal').value).toLowerCase();
	let algorithmType = (document.getElementById('algorithmType').value).toLowerCase();
   
	// 체크된 항목들의 변수명을 배열로 수집
    let selectedFiltering = [];
    if(algorithmType=="cluster"){
    	$('.variable-checkbox:checked').each(function() {
        	selectedFiltering.push($(this).data('variable-name'));
        	console.log(selectedFiltering);
        });
    	
    } else if(algorithmType=="regression"){
    	$('.filtering-checkbox:checked').each(function() {
    		selectedFiltering.push($(this).data('filtering-name'));
    		console.log(selectedFiltering);
    	});
    }
    
    Load.showLoader();
    console.log(selectedFiltering);
    console.log(target);
    console.log(evalRatio);
    console.log(reTrain);
    console.log(reTrainId);
    console.log(parameters);
    console.log(algorithmType);
    console.log(algorithmVal);


	// Java로 전송
    $.ajax({
        url: 'sendFiltering', // 데이터를 전송할 Java 서버의 엔드포인트 URL
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	selectedFiltering: selectedFiltering,
            target: target,
            evalRatio: evalRatio,
            reTrain: reTrain,
            modelId: reTrainId,
            params: parameters,
            algorithmType: algorithmType,
            algorithmVal: algorithmVal
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            if(algorithmType=="cluster"){
            	gridTrainResult2(data, algorithmVal);
            }else if(algorithmType=="regression"){
            	gridTrainResult(data, algorithmVal);
            }
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
        	Load.hideLoader();
        }
    });
}


function gridAlgorithmSelect() {
	let setpId = "algorithmSelect";
	currentPid = "algorithmSelect";
	
	let resultStr = 
		"<div class=\"col-lg-6\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body upload_box\">\r\n" + 
		"            <div class=\"img_area\"><img src=\"images/algorithm_01.png\"></div>\r\n" + 
		"            <div class=\"btn_area\"><button type=\"button\" onclick=\"gridAlgorithmDetail('cluster');\" class=\"btn waves-effect waves-light btn-rounded btn-primary\">군집 알고리즘</button></div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>\r\n" + 
		"<div class=\"col-lg-6\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body upload_box\">\r\n" + 
		"            <div class=\"img_area\"><img src=\"images/algorithm_02.png\"></div>\r\n" + 
		"            <div class=\"btn_area\"><button type=\"button\" onclick=\"gridAlgorithmDetail('regression');\" class=\"btn waves-effect waves-light btn-rounded btn-primary\">시계열 알고리즘</button></div>\r\n" + 
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div>";
	
	document.getElementById(setpId).innerHTML = resultStr;

	displaySelector(setpId);
}

function gridRegParameters(algorithm) {
	let algorithmList = ['LSTM', 'ARIMA', 'PMDARIMA', 'PROPHET', 'ELASTIC-NET'];
	let algorithmList2 = ['LOF', 'DBSCAN', 'ISOLATION-FOREST', 'K-MEANS', 'GAUSSIAN-MIXTURE'];
	let algorithmSet = "";
	algorithmSet +=
		"	<div class=\"col-lg-12\" style=\"margin-top: 0px; padding-top: 0px;\">\r\n" + 
		"         <div class=\"card\" style=\"margin-top: 0px; padding-top: 0px;\">\r\n" + 
		"             <div class=\"card-body\" style=\"height:179px;\">\r\n" + 
		"                 <div>\r\n" + 
		"                     <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\" id=\"ALGORITHM-TB\">\r\n"; 
	if(algorithm.toUpperCase() == 'LSTM'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">hidden_size</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=64></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">num_layers </td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=2></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">dropout</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.3></td>\r\n" + 
			"                         </tr>\r\n";
	} else if(algorithm.toUpperCase() == 'ARIMA'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">p</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=2></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">d</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=2></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">q</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=2></td>\r\n" + 
			"                         </tr>\r\n";
		
	} else if(algorithm.toUpperCase() == 'PMDARIMA'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">해당 알고리즘은 패러미터가 자동으로 설정 됩니다.</td>\r\n" + 
			"                         </tr>\r\n";
		
	} else if(algorithm.toUpperCase() == 'PROPHET'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">changepoint_prior_scale</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.1></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">interval_width</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.95></td>\r\n" + 
			"                         </tr>\r\n";
	} else if(algorithm.toUpperCase() == 'ELASTIC-NET'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">alpha</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.3></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">l1_ratio</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=1></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">lag</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=3></td>\r\n" + 
			"                         </tr>\r\n";
	} else if(algorithm.toUpperCase() == 'LOF'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">n_neighbors</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=20></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">contamination</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.05></td>\r\n" + 
			"                         </tr>\r\n";
		
	} else if(algorithm.toUpperCase() == 'DBSCAN'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">eps</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.5></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">min_samples</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=5></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">leaf_size</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=30></td>\r\n" + 
			"                         </tr>\r\n";
		
	} else if(algorithm.toUpperCase() == 'ISOLATION-FOREST'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">n_estimators</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=100></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">contamination</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.1></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">random_state</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=42></td>\r\n" + 
			"                         </tr>\r\n";
	} else if(algorithm.toUpperCase() == 'K-MEANS'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">n_clusters</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=8></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">n_init</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=10></td>\r\n" + 
			"                         </tr>\r\n";
	} else if(algorithm.toUpperCase() == 'GAUSSIAN-MIXTURE'){
		algorithmSet +=
			"                         <tr>\r\n" + 
			"                             <td width=\"10%\" style=\"border: none;\">n_components</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=100></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">contamination</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=0.05></td>\r\n" + 
			"                         </tr>\r\n" + 
			"                         <tr>\r\n" + 
			"                             <td style=\"border: none;\">max_iter</td>\r\n" + 
			"                             <td style=\"border: none;\"><input type=\"text\" class=\"text_box\" style=\"width: 99%;\" value=2></td>\r\n" + 
			"                         </tr>\r\n";
	}
	algorithmSet +=
		"                     </table>\r\n" + 
		"                 </div>\r\n" + 
		"             </div>\r\n" + 
		"         </div>\r\n" + 
		"     </div>\r\n";
	
	document.getElementById("algorithmParameters").innerHTML = algorithmSet;
	document.getElementById("algorithmVal").value = algorithm;
	
	let algorithmContainer = '#ALGORITHM-TB' + ' .text_box';
	
	parameters = {};
	$(algorithmContainer).each(function() {
		let key = $(this).closest('tr').find('td:first').text().trim(); // Key는 첫 번째 <td>의 텍스트
		let value = $(this).val(); // Value는 input 필드 값
		parameters[key] = value;
	});
	console.log(parameters);
	
}

function gridAlgorithmDetail(type) {
	document.getElementById("algorithmType").value = type;
	let setpId = "algorithmDetail";
	currentPid = "algorithmDetail";
	if(type=="cluster"){
let algorithmList = ['LOF', 'DBSCAN', 'ISOLATION-FOREST', 'K-MEANS', 'GAUSSIAN-MIXTURE'];
		
		let resultStr = 
			"<div class=\"card-group\" style=\"margin-bottom: 0px;\" id=\"algorithmGroup\">\r\n";
		for (let i = 0; i < algorithmList.length; i++) {
			if(i==0){
				resultStr += 
					"     <div id=\"alck"+(i+1)+"\" class=\"card border-right\" onclick=\"gridRegParameters('"+algorithmList[i]+"');\">\r\n" + 
					"         <div class=\"card-body bg_0"+(i+1)+"\">\r\n" + 
					"             <div class=\"text_center\">\r\n" + 
					"                 <h3 class=\"font-weight-medium font_white\">"+algorithmList[i]+"</h3>\r\n" + 
					"                 <h6 class=\"font_white\"></h6>\r\n" + 
					"			</div>\r\n" + 
					"         </div>\r\n" + 
					"     </div>\r\n";
				
			}else{
				resultStr += 
					"     <div id=\"alck"+(i+1)+"\" class=\"card border-right\" onclick=\"gridRegParameters('"+algorithmList[i]+"');\">\r\n" + 
					"         <div class=\"card-body\" style=\"background-color: rgb(238, 238, 238);\">\r\n" + 
					"             <div class=\"text_center\">\r\n" + 
					"                 <h3 class=\"font-weight-medium\">"+algorithmList[i]+"</h3>\r\n" + 
					"                 <h6 class=\"font_white\"></h6>\r\n" + 
					"			</div>\r\n" + 
					"         </div>\r\n" + 
					"     </div>\r\n";
			}
		}
		resultStr += 
			" </div> <!-- card-group -->\r\n" + 
			" <div class=\"row\" id=\"algorithmParameters\">\r\n" + 
			"</div> <!-- row -->\r\n" + 
			"             <div class=\"right_20\"><button type=\"button\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\" onclick=\"sendSelectedFiltering();\">학습 실행</button></div>\r\n" + 
			" <div class=\"row\" style=display:none;>\r\n" + 
			"	<!-- column -->\r\n" + 
			"	<div class=\"col-lg-12\">\r\n" + 
			"         <div class=\"card\">\r\n" + 
			"             <div class=\"card-body3\">\r\n" + 
			"                 <h4 class=\"card-title\">검증 데이터 비율 설정</h4>\r\n" + 
			"        <div class=\"slider-container\">\r\n" + 
			"            <div class=\"slider-track\" id=\"slider-track\">\r\n" + 
			"                <div class=\"slider-bar\" id=\"slider-bar\" style=\"width: 5%;\"></div>\r\n" + 
			"                <div class=\"slider-handle\" id=\"slider-handle\" style=\"left: 5%;\">\r\n" + 
			"                    <div class=\"tooltipp\" id=\"slider-tooltip\">5%</div>\r\n" + 
			"                </div>\r\n" + 
			"            </div>\r\n" + 
			"            <div class=\"slider-labels\">\r\n" + 
			"                <span>0%</span>\r\n" + 
			"                <span>100%</span>\r\n" + 
			"            </div>\r\n" + 
			"        </div>" +
			"             </div>\r\n" + 
			"         </div>\r\n" + 
			"     </div>\r\n" + 
			"	<!-- column -->\r\n" + 
			"</div> <!-- row -->\r\n" + 
			" </div>";
		
		document.getElementById(setpId).innerHTML = resultStr;

		gridRegParameters('LOF');
		
	} else if(type=="regression"){
		
		let algorithmList = ['LSTM', 'ARIMA', 'PMDARIMA', 'PROPHET', 'ELASTIC-NET'];
		
		let resultStr = 
			"<div class=\"card-group\" style=\"margin-bottom: 0px;\" id=\"algorithmGroup\">\r\n";
		for (let i = 0; i < algorithmList.length; i++) {
			if(i==0){
				resultStr += 
					"     <div id=\"alck"+(i+1)+"\" class=\"card border-right\" onclick=\"gridRegParameters('"+algorithmList[i]+"');\">\r\n" + 
					"         <div class=\"card-body bg_0"+(i+1)+"\">\r\n" + 
					"             <div class=\"text_center\">\r\n" + 
					"                 <h3 class=\"font-weight-medium font_white\">"+algorithmList[i]+"</h3>\r\n" + 
					"                 <h6 class=\"font_white\"></h6>\r\n" + 
					"			</div>\r\n" + 
					"         </div>\r\n" + 
					"     </div>\r\n";
				
			}else{
				resultStr += 
					"     <div id=\"alck"+(i+1)+"\" class=\"card border-right\" onclick=\"gridRegParameters('"+algorithmList[i]+"');\">\r\n" + 
					"         <div class=\"card-body\" style=\"background-color: rgb(238, 238, 238);\">\r\n" + 
					"             <div class=\"text_center\">\r\n" + 
					"                 <h3 class=\"font-weight-medium\">"+algorithmList[i]+"</h3>\r\n" + 
					"                 <h6 class=\"font_white\"></h6>\r\n" + 
					"			</div>\r\n" + 
					"         </div>\r\n" + 
					"     </div>\r\n";
			}
		}
		resultStr += 
			" </div> <!-- card-group -->\r\n" + 
			" <div class=\"row\" id=\"algorithmParameters\">\r\n" + 
			"</div> <!-- row -->\r\n" + 
			" <div class=\"row\">\r\n" + 
			"	<!-- column -->\r\n" + 
			"	<div class=\"col-lg-12\">\r\n" + 
			"         <div class=\"card\">\r\n" + 
			"             <div class=\"card-body3\">\r\n" + 
			"                 <h4 class=\"card-title\">검증 데이터 비율 설정</h4>\r\n" + 
			"        <div class=\"slider-container\">\r\n" + 
			"            <div class=\"slider-track\" id=\"slider-track\">\r\n" + 
			"                <div class=\"slider-bar\" id=\"slider-bar\" style=\"width: 5%;\"></div>\r\n" + 
			"                <div class=\"slider-handle\" id=\"slider-handle\" style=\"left: 5%;\">\r\n" + 
			"                    <div class=\"tooltipp\" id=\"slider-tooltip\">5%</div>\r\n" + 
			"                </div>\r\n" + 
			"            </div>\r\n" + 
			"            <div class=\"slider-labels\">\r\n" + 
			"                <span>0%</span>\r\n" + 
			"                <span>100%</span>\r\n" + 
			"            </div>\r\n" + 
			"        </div>" +
			"             </div>\r\n" + 
			"             <div class=\"right_20\"><button type=\"button\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\" onclick=\"sendSelectedFiltering();\">학습 실행</button></div>\r\n" + 
			"         </div>\r\n" + 
			"     </div>\r\n" + 
			"	<!-- column -->\r\n" + 
			"</div> <!-- row -->\r\n" + 
			" </div>";
		
		document.getElementById(setpId).innerHTML = resultStr;

		gridRegParameters('LSTM');
		
		const track = document.getElementById("slider-track");
		const bar = document.getElementById("slider-bar");
		const handle = document.getElementById("slider-handle");
		const tooltip = document.getElementById("slider-tooltip");
		
		setupSliderEvents(track, bar, handle, tooltip);
	}
	
	
	// 알고리즘 선택 동작
	document.querySelector('#algorithmGroup').addEventListener('click', function (event) {
		const clickedCardBody = event.target.closest('.card-body');
		if (!clickedCardBody) return;
		
	    const cardBodis = document.querySelectorAll('#algorithmDetail .card-group .card .card-body');
	    cardBodis.forEach((cardBody, index) => {
	    	cardBody.className = 'card-body';
	    	cardBody.style.backgroundColor = '#EEEEEE';
	    	
	    	const h3Tag = cardBody.querySelector('h3');
	    	h3Tag.className = 'font-weight-medium';
	    	const h6Tag = cardBody.querySelector('h6');
	    	h6Tag.className = '';

	    	if (cardBody === clickedCardBody) {
	    			cardBody.classList.add(`bg_0${index + 1}`);
	    			cardBody.style.backgroundColor = '';
	    			h3Tag.className = 'font-weight-medium font_white';
	    			h6Tag.className = 'font_white';
	    	}
	    });
	});

	displaySelector(setpId);
}

function setupSliderEvents(track, bar, handle, tooltip) {
    function setSliderPosition(percent) {
        bar.style.width = percent + '%';
        handle.style.left = percent + '%';

        // 툴팁 위치와 텍스트 업데이트
        tooltip.style.left = percent + '%';
        tooltip.innerText = Math.round(percent) + '%';
    }

    track.addEventListener('click', function(event) {
        const percent = (event.offsetX / track.offsetWidth) * 100;
        setSliderPosition(Math.max(5, Math.min(95, percent))); // 5% ~ 95% 범위 설정
    });

    handle.addEventListener('mousedown', function(event) {
        event.preventDefault();
        document.addEventListener('mousemove', onDrag);
        document.addEventListener('mouseup', stopDrag);
    });

    function onDrag(event) {
        const rect = track.getBoundingClientRect();
        const offsetX = event.clientX - rect.left;
        let percent = (offsetX / track.offsetWidth) * 100;
        percent = Math.max(5, Math.min(95, percent)); // 5% ~ 95% 범위 설정
        setSliderPosition(percent);
    }

    function stopDrag() {
        document.removeEventListener('mousemove', onDrag);
        document.removeEventListener('mouseup', stopDrag);
    }
}


function gridTrainResult(parsedData, algorithmVal) {

	let scoreMap = parsedData.scoreMap;
	
	let oob_score = parseFloat(scoreMap.train_score).toFixed(2);
	let test_score = (1-parseFloat(scoreMap.test_score)).toFixed(2);
	let mse = parseFloat(scoreMap.mse).toFixed(2);
	let rmse = parseFloat(scoreMap.rmse).toFixed(2);
	let mape = parseFloat(scoreMap.mape).toFixed(2);
	let acc = (1-parseFloat(scoreMap.mape)).toFixed(2);
	let reTrainChk = document.getElementById("reTrainChk").value;
	
	let setpId = "trainResult";
	currentPid = "trainResult";
	displaySelector(setpId);
	
	let resultStr = 
		"<div class=\"col-lg-12\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body\">\r\n" + 
		"            <div class=\"graph_area\"> <!-- display: none; 일 경우 width: 100%; -->\r\n" + 
		"			 <canvas id=\"myChart\" width=\"400\" height=\"200\"></canvas>\r\n" + 
		"            </div>\r\n" + 
		"            <div class=\"top_20\"></div>\r\n" + 
		"            <div class=\"table_area4\"> \r\n" + 
		"                <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"                    <thead>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <th scope=\"col\" width=\"25%\">평가 항목</th>\r\n" + 
		"                        <th scope=\"col\" width=\"25%\">값</th>\r\n" + 
		"                      </tr>\r\n" + 
		"                    </thead>\r\n" + 
		"                    <tbody>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <td>OOB_SCORE</td>\r\n" + 
		"                        <td>"+oob_score+"</td>\r\n" + 
		"                      </tr>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <td>TEST_SCORE</td>\r\n" + 
		"                        <td>"+test_score+"</td>\r\n" + 
		"                      </tr>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <td>MSE</td>\r\n" + 
		"                        <td>"+mse+"</td>\r\n" + 
		"                      </tr>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <td>RMSE</td>\r\n" + 
		"                        <td>"+rmse+"</td>\r\n" + 
		"                      </tr>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <td>MAPE</td>\r\n" + 
		"                        <td>"+mape+"</td>\r\n" + 
		"                      </tr>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <td>ACCURACY</td>\r\n" + 
		"                        <td>"+acc+"</td>\r\n" + 
		"                      </tr>\r\n" + 
		"                    </tbody>\r\n" + 
		"                </table>\r\n" + 
		"            </div>\r\n";
	if(reTrainChk=="0"){
		resultStr += 
			"            <button type=\"button\" onclick=\"modelNameModal();\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">모델확정</button>\r\n"; 
	}else{
		document.getElementById("modalModelName").value="reModel";
		resultStr += 
			"            <button type=\"button\" onclick=\"insertModelInfo();\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">모델확정</button>\r\n"; 
	}
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div> ";
	
	document.getElementById(setpId).innerHTML = resultStr;
	
	
    var ctx = document.getElementById('myChart').getContext('2d');
	let chartList = parsedData.chartList;
	let chartData = chartList.map(function(item) {
        return JSON.parse(item.jsonResponse);
    });
//	console.log(chartData);
	
	let labels = chartData.map(function(item) {
        return item.labels;
    });
	
	let datasets = chartData.map(function(item) {
		return item.datasets;
	});

    labels = labels.flat();
    datasets = datasets.flat();
	console.log(labels);
	console.log(datasets);
    
	var myChart = new Chart(ctx, {
	    type: 'line',
	    data: {
	    	labels: labels,
	    	datasets: datasets
	    },
	    options: {
	        responsive: true,
	        plugins: {
	            legend: {
	                display: true,
	                position: 'top'
	            }
	        },
	        scales: {
	            x: {
	                title: {
	                    display: true,
	                    text: '날짜'
	                }
	            },
	            y: {
	                title: {
	                    display: true,
	                    text: '값'
	                }
	            }
	        }
	    }
	});
}


function gridTrainResult2(parsedData, algorithmVal) {

	let setpId = "trainResult";
	currentPid = "trainResult";
	let reTrainChk = document.getElementById("reTrainChk").value;
	displaySelector(setpId);
	
	let resultStr = 
		"<div class=\"col-lg-12\">\r\n" + 
		"    <div class=\"card\">\r\n" + 
		"        <div class=\"card-body\">\r\n" + 
		"            <div class=\"graph_area\"> <!-- display: none; 일 경우 width: 100%; -->\r\n" + 
		"			 <canvas id=\"myChart\" width=\"400\" height=\"200\"></canvas>\r\n" + 
		"            </div>\r\n" + 
		"            <div class=\"top_20\"></div>\r\n" + 
		"            <div class=\"table_area4\"> \r\n" + 
		"                <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"table\">\r\n" + 
		"                    <thead>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <th scope=\"col\" width=\"25%\">평가 항목</th>\r\n" + 
		"                        <th scope=\"col\" width=\"25%\">값</th>\r\n" + 
		"                      </tr>\r\n" + 
		"                    </thead>\r\n" + 
		"                    <tbody>\r\n" + 
		"                      <tr>\r\n" + 
		"                        <td colspan='2'>비지도학습은 평가지표가 없습니다.</td>\r\n" + 
		"                      </tr>\r\n" + 
		"                    </tbody>\r\n" + 
		"                </table>\r\n" + 
		"            </div>\r\n";
	
	if(reTrainChk=="0"){
		resultStr += 
			"            <button type=\"button\" onclick=\"modelNameModal();\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">모델확정</button>\r\n"; 
	}else{
		document.getElementById("modalModelName").value="reModel";
		resultStr += 
			"            <button type=\"button\" onclick=\"insertModelInfo();\" class=\"btn waves-effect waves-light btn-sm btn-secondary fr mtb_1020\">모델확정</button>\r\n"; 
	}
		"        </div>\r\n" + 
		"    </div>\r\n" + 
		"</div> ";
	
	document.getElementById(setpId).innerHTML = resultStr;

//	let scatterDataset = JSON.parse(parsedData.jsonResponse);
	let chartList = parsedData.chartList;
	let chartData = chartList.map(function(item) {
        return JSON.parse(item.jsonResponse);
    });
	console.log(chartData);
	
	let labels = chartData.map(function(item) {
        return item.labels;
    });
	
	let datasets = chartData.map(function(item) {
		return item.datasets;
	});

    labels = labels.flat();
    datasets = datasets.flat();
	console.log(labels);
	console.log(datasets);
	
    // Chart.js Scatter 차트 생성
    const ctx = document.getElementById('myChart').getContext('2d');
    new Chart(ctx, {
        type: 'scatter',
        data: {
        	labels : labels,
        	datasets : datasets
        },
        options: {
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            // 데이터 포인트의 인덱스 가져오기
                            const index = context.dataIndex;
                            const pointData = datasets[0].data[index];

                            // 툴팁에 표시할 내용 구성
                            return [
                                `x: ${pointData.x}`,
                                `y: ${pointData.y}`,
                                `Score: ${pointData.score.toFixed(2)}`,
                                `Outlier: ${pointData.outlier ? 'Yes' : 'No'}`
                            ];
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Index'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Feature Value'
                    }
                }
            }
        }
    });
}

function modelNameModal() {
	let modal = document.getElementById("modelModal");
	modal.style.display = "block";
}

function modalClose() {
	let modal = document.getElementById("modelModal");
	modal.style.display = "none";
}

function insertModelInfo() {
	
	let modal = document.getElementById("modelModal");
	let modelViewName = document.getElementById("modalModelName").value;
	if(modelViewName.length>1){
		modal.style.display = "none";
		Load.showLoader();
		$.ajax({
	        url: 'insertModelInfo', // 데이터를 전송할 Java 서버의 엔드포인트 URL
	        type: 'POST',
	        contentType: 'application/json',
	        data: JSON.stringify({
	        	modelViewName: modelViewName
	        }),
	        success: function(data) {
	            console.log('서버 응답:', data);
	            gridFixModel();
	        },
	        error: function(xhr, status, error) {
	            console.error('전송 오류:', error);
	        },
	        complete: function() {
	        	Load.hideLoader();
	        }
	    });
	}else{
		alert("2자 이상의 이름을 입력해주세요");
	}
	
}

function gridFixModel() {
	let setpId = "fixModel";
	currentPid = "fixModel";
	displaySelector(setpId);
	
	let resultStr = 
		"<ul>\r\n" + 
		"    <li><h3>시계열모델 학습이 완료 되었습니다.</h3></li>\r\n" + 
		"    <li><h3>모델관리에서 모델의 정보를 확인 할 수 있습니다.</h3></li>\r\n" + 
		"    <li><button type=\"button\" onclick=\"goMgnt();\" class=\"btn waves-effect waves-light btn-rounded btn-primary\">모델 관리</button></li>\r\n" + 
		"</ul>";
	
	document.getElementById(setpId).innerHTML = resultStr;
}

function goMgnt() {
	window.location.href = "modelMgmt";
}

document.addEventListener("DOMContentLoaded", function() {
	let callTrainChk = document.getElementById("callTrainChk").value;
	if(callTrainChk=="1"){
		requestReTrainList();
    }else{
    	gridTrainMode();
		displaySelector("trainMode");
    }
    console.log(idValue); // 페이지가 로드될 때 호출
    
});


/** 로딩 이미지 사용
 * 사용 : Load.showLoader();
 * 미사용 : Load.hideLoader();
 */
const Load = (function () {
    const loader = document.getElementById("load");
    return {
        showLoader: function () {
            loader.style.cssText = "display:show";
        },
        hideLoader: function () {
            loader.style.cssText = "display:none";
        }
    };
})();

let conkord = function() {
	let asdfwaev = "awefawegaewgawehgwehfblk;ja;ioegjaweg";
	let rncjsdhqordnjs = 'dd';
	let lweiaef = "dkssudgktpdy";
	
	let dkdhdlwkzk = "aoharide";
}

let combine = function() {
	let comone = "exa";
	let comtwo = "rrqqcv"
}