let prdChart = null;
let dtChart = null;

function displaySelector(id) {
	
	const trainDiv = document.getElementById("excuteDiv");
	const childDivs = trainDiv.children;

	Array.from(childDivs).forEach(child => {
	  if (child.tagName === "DIV") {
	    child.style.display = "none";
	  }
	});
	
	document.getElementById(id).style.display = "";
}

function selectModelList() {

	$.ajaxSetup({cache:false});
	$.ajax({
		contentType : "application/json; charset=UTF-8",
		type : "POST",
		url : "selectModelInfo",
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			gridModelOpt(data);
		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
}

function gridModelOpt(data) {
	let setpId = "modelOpt";
//	displaySelector(setpId);
	let resultStr = "";
	for(let i=0; i<data.length; i++){
			
			let mdId = data[i].MODEL_ID;
			let mdDate = data[i].FIRST_TRAIN_DATE;
			let mdState = data[i].MODEL_STATE;
			let mdStateKr = "";
			let mdName = data[i].MODEL_VIEW_NAME;
			let mdCnt = data[i].TRAIN_CNT;
			let mdFile = data[i].TRAIN_DATA_FILE;
			let mdFilePath = data[i].TRAIN_DATA_PATH;
			let modelTypes = data[i].MODEL_TYPES;
			
			if (mdState=="s"){
				mdStateKr = "실행중";
			} else{
				mdStateKr = "대기중";
			}
			resultStr += 
				"<option value=\""+modelTypes+","+mdId+"\">"+mdName+"</option>\r\n"; 
	}
	
	document.getElementById(setpId).innerHTML = resultStr;

	selectOpt();
}

function selectOpt() {
    const dropdown = document.getElementById('modelOpt');
    const algorithmType = dropdown.value.split(",")[0]; // 선택된 알고리즘 유형 regression OR cluster
    console.log("선택된 값:", algorithmType);
    const modelId = dropdown.value.split(",")[1]; // 선택된 값 가져오기
    document.getElementById("ALGORITHM_TYPE").value = algorithmType;
    document.getElementById("MODEL_ID").value = modelId;
	
    const trainDiv = document.getElementById("excuteDiv");
	const childDivs = trainDiv.children;

	Array.from(childDivs).forEach(child => {
	  if (child.tagName === "DIV") {
	    child.style.display = "none";
	  }
	});
	
	document.getElementById(algorithmType).style.display = "";

	document.getElementById('searchTab').style.display = "none";
	
	if(algorithmType=="cluster"){
		requestFeatures();
	} else if(algorithmType=="regression"){
		gridRegression();
		requestRegression("365"); 
		requestData("365");
	}
}

function requestFeatures() {
	let modelId = document.getElementById("MODEL_ID").value;
	
	$.ajax({
        url: 'requestFeatures', // 데이터를 전송할 Java 서버의 엔드포인트 URL
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	id: modelId
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridCluster(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
//        	Load.hideLoader();
        }
    });
	
} 

function gridCluster(data) {
	let setpId = "eval";
	displaySelector(setpId);
//	document.getElementById('searchTab').style.display = "";
	let features = "";
	let resultStr = 
		"    <div class=\"bar\"></div>\r\n" + 
		"    <h4 class=\"card-title mt_20\">배출량 학습 결과 그래프</h4>\r\n" + 
		"    <div id=\"graph_area\" style=\"height:450px; width:800px;\"> <!-- style 삭제 요망 -->\r\n" + 
		"    	<canvas id=\"predictChart\"></canvas>\r\n" + 
		"    </div>\r\n" + 
		"    <div class=\"fr mt_20\">\r\n";
	for(let i=0; i<data.length; i++){
		resultStr += 
			"        <p>"+data[i]+" : <input type=\"text\" class=\"text_box2\" placeholder=\"데이터 입력\" id=\""+data[i]+"\">";
		if(i==0){
			features += data[i];
		}else{
			features += ","+data[i];
		}
	}
	resultStr += 
		"		 <button class=\"btn waves-effect waves-light btn-sm btn-secondary\" onclick=\"requestCluster('"+features+"');\">검증</button></p>\r\n" + 
		"        <p id=\"outliarResult\"></p>\r\n" + 
		"    </div>\r\n";
	
	document.getElementById(setpId).innerHTML = resultStr;
}

function gridRegression() {
	let setpId = "regression";
//	displaySelector(setpId);
	
	let resultStr = 
		"<div class=\"graph_area_fl\">\r\n" + 
		"	<h4 class=\"card-title mt_20\">지역별 보관량 데이터</h4>\r\n" + 
		"	<div class=\"bottom_10 fr\">\r\n" + 
		"		<button class=\"btn_date\" onclick=\"requestData('365');\">분기별</button>\r\n" + 
		"		<button class=\"btn_date\" onclick=\"requestData('1461');\">년별</button>\r\n" + 
//		"		<button class=\"btn_date\">기간별</button>\r\n" + 
		"	</div>\r\n" + 
		"	<div class=\"clear\"></div>\r\n" + 
		"<div style=\"width: 80%; margin: auto;\" id=\"delPredict\">\r\n" + 
		"    <canvas id=\"dataChart\"></canvas>\r\n" + 
		"</div>" +
		"</div> <!-- graph_area_fl -->\r\n" + 
		"<div class=\"graph_area_fr\">\r\n" + 
		"	<h4 class=\"card-title mt_20\">지역별 보관량 예측</h4>\r\n" + 
		"	<div class=\"bottom_10 fr\">\r\n" + 
		"		<button class=\"btn_date\" onclick=\"requestRegression('365');\">분기별</button>\r\n" + 
		"		<button class=\"btn_date\" onclick=\"requestRegression('1461');\">년별</button>\r\n" + 
//		"		<button class=\"btn_date\">기간별</button>\r\n" + 
		"	</div>\r\n" + 
		"<div style=\"width: 80%; margin: auto;\" id=\"delPredict\">\r\n" + 
		"    <canvas id=\"predictChart\"></canvas>\r\n" + 
		"</div>" +
		"	</div>\r\n" + 
		"</div> <!-- graph_area_fr -->";

	document.getElementById(setpId).innerHTML = resultStr;
}

function requestCluster(features) {
	let modelId = document.getElementById("MODEL_ID").value;
	let algorithmType = document.getElementById("ALGORITHM_TYPE").value;
	let outlierVal = {};
	console.log(features);
	let featureList = features.split(",");
	console.log(featureList);
	
	for(let i=0; i<featureList.length; i++){
		console.log(document.getElementById(featureList[i]));
		outlierVal[featureList[i]] = document.getElementById(featureList[i]).value;
	}
	console.log(outlierVal);
//	let outlierVal = document.getElementById("outlierVal");
//	outlierVal = outlierVal ? outlierVal.value : null; // 없는 경우 null 할당
	
	$.ajax({
        url: 'requestPredict', // 데이터를 전송할 Java 서버의 엔드포인트 URL
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	id: modelId,
        	algorithmType: algorithmType,
        	outlierVal: outlierVal
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridPredictChart(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
//        	Load.hideLoader();
        }
    });
}

function requestRegression(period) {
	let modelId = document.getElementById("MODEL_ID").value;
	let algorithmType = document.getElementById("ALGORITHM_TYPE").value;
	
	$.ajax({
        url: 'requestPredict', // 데이터를 전송할 Java 서버의 엔드포인트 URL
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	id: modelId,
        	algorithmType: algorithmType,
            period: period
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridPredictChart(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
//        	Load.hideLoader();
        }
    });
}

let myChart = null;

function gridPredictChart(data) {
//	outliarResult
	let labels = "검증 결과 : <span class=\"color_normal\">정상수치</span> or <span class=\"error_normal\">이상수치</span>";
	let algorithmType = document.getElementById("ALGORITHM_TYPE").value;
	
	let chartList = data;
	let chartData = chartList.map(function(item) {
        return JSON.parse(item.jsonResponse);
    });
	console.log(chartData);
	
	let input_outliar = chartData.map(function(item) {
        return item.input_outliar;
    });
	
	let datasets = chartData.map(function(item) {
		return item.datasets;
	});

	input_outliar = input_outliar.flat();
    datasets = datasets.flat();
	console.log(input_outliar);
	console.log(datasets);
    
	var ctx = document.getElementById('predictChart').getContext('2d');
	// 기존 차트를 삭제
    if (myChart !== null) {
        myChart.destroy(); // 기존 차트를 삭제
    }
	if(algorithmType=="cluster"){
		myChart = new Chart(ctx, {
	        type: 'scatter',
	        data: {
	        	datasets : datasets
	        },
	        options: {
	            plugins: {
	                tooltip: {
	                    callbacks: {
	                        label: function (context) {
	                            // 데이터 포인트의 인덱스 가져오기
	                            const index = context.dataIndex;
	                            const pointData = datasets[0].data[index];

	                            // 툴팁에 표시할 내용 구성
	                            return [
	                                `x: ${pointData.x}`,
	                                `y: ${pointData.y}`,
	                                `Score: ${pointData.score.toFixed(2)}`,
	                                `Outlier: ${pointData.outlier ? '이상치' : '정상'}`
	                            ];
	                        }
	                    }
	                }
	            },
	            scales: {
	                x: {
	                    title: {
	                        display: true,
	                        text: 'Index'
	                    }
	                },
	                y: {
	                    title: {
	                        display: true,
	                        text: 'Feature Value'
	                    }
	                }
	            }
	        }
	    });
		
	} else if(algorithmType=="regression"){
		myChart = new Chart(ctx, {
			type: 'line',
			data: {
				labels: labels,
				datasets: datasets
			},
			options: {
				responsive: true,
				plugins: {
					legend: {
						display: true,
						position: 'top'
					}
				},
				scales: {
					x: {
						title: {
							display: true,
							text: '날짜'
						}
					},
					y: {
						title: {
							display: true,
							text: '값'
						}
					}
				}
			}
		});
	}
}

function requestData(period) {
	let modelId = document.getElementById("MODEL_ID").value;
	
	$.ajax({
        url: 'requestData', // 데이터를 전송할 Java 서버의 엔드포인트 URL
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
        	id: modelId,
            period: "period"
        }),
        success: function(data) {
            console.log('서버 응답:', data);
            gridDataChart(data);
        },
        error: function(xhr, status, error) {
            console.error('전송 오류:', error);
        },
        complete: function() {
//        	Load.hideLoader();
        }
    });
}

function gridDataChart(data) {
	
	const totalData = data.length;
    const step = Math.floor(totalData / 10);  // 10개로 나누기 위한 간격

    // 3. 구간별로 데이터를 추출
    const reducedData = [];
    for (let i = 0; i < 10; i++) {
        reducedData.push(data[i * step]); // 10개의 데이터 추출
    }

    // 4. Chart.js에서 사용할 데이터 변환
    const labels = reducedData.map(item => item.Date); // X축 날짜
    const targetData = reducedData.map(item => item.target); // target 값

    // 5. 유동적으로 features의 key를 추출하여 datasets 생성
    const featureKeys = new Set();
    reducedData.forEach(item => {
        item.features.forEach(feature => {
            Object.keys(feature).forEach(key => featureKeys.add(key)); // feature의 key를 모두 추가
        });
    });

    // 6. featureKey에 따라 데이터셋 생성
    const datasets = Array.from(featureKeys).map(featureKey => {
        const featureData = reducedData.map(item => {
            return item.features.reduce((sum, feature) => sum + (feature[featureKey] || 0), 0);
        });
        return {
            label: featureKey, // feature 이름을 레이블로 설정
            data: featureData,
            backgroundColor: 'rgba(75, 192, 192, 0.2)', // 임의의 색상
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        };
    });

    // Target 데이터셋 추가 (강조 스타일 적용)
    datasets.unshift({
        label: 'Target',
        data: targetData, // target 값
        backgroundColor: 'rgba(255, 99, 132, 0.6)', // 강조된 색상
        borderColor: 'rgba(255, 99, 132, 1)', // 굵은 테두리
        borderWidth: 3, // 더 두꺼운 테두리
        hoverBackgroundColor: 'rgba(255, 99, 132, 0.8)', // 마우스 오버시 강조 색상
        hoverBorderColor: 'rgba(255, 99, 132, 1)', // 마우스 오버시 테두리 색상
        hoverBorderWidth: 4 // 마우스 오버시 테두리 두께
    });

    const chartData = {
        labels: labels, // 날짜
        datasets: datasets // 유동적으로 생성된 datasets
    };
    if (dtChart !== null) {
    	dtChart.destroy(); // 기존 차트를 삭제
    }
    // 7. 차트 생성
    const ctx = document.getElementById('dataChart').getContext('2d');
    dtChart = new Chart(ctx, {
        type: 'bar', // 막대 그래프
        data: chartData,
        options: {
            responsive: true,
            scales: {
                x: {
                    beginAtZero: true
                },
                y: {
                    beginAtZero: true
                }
            }
        }
    });
} 

document.addEventListener("DOMContentLoaded", function() {
	selectModelList();
});




function selectViewAndDetailList(id) {

	$.ajaxSetup({cache:false});
	$.ajax({
		type : "POST",
		url : "selectViewAndDetailList",
        contentType: 'application/json',
        data: JSON.stringify({
            id: id
        }),
		cache: false,
		timeout : 30000,
		success : function(data) {
			console.log(data);
			document.getElementById("MODEL_ORG_NAME").value = data.MODEL_ORG_NAME;
			document.getElementById("TARGET_VAL").value = data.TARGET_VAL;
			document.getElementById("TRAIN_DATA_FILE").value = data.TRAIN_DATA_FILE;
		},
		error: function(jqxhr, status, error){
			console.log(jqxhr.statusText + ",  " + status + ",   " + error);
			console.log(jqxhr.status);
			console.log(jqxhr.responseText);
		}
	});
}


